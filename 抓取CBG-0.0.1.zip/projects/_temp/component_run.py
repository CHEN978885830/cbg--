
import sys
import os
from common.util.recursive_util import tail_call_optimized
from common.util.decryption_util import decrypt,encryption
from common.util.get_config_util import get_config
from common.util.log_util import trace_log
from common.util.option_util import options
from common.util.elements_util import elementsFormat, elementsFormatNew, collectElementsFormat, child_ele_eval
from common.util.judge_components import *
from common.util.selector_array import get_selector_array,get_selector_array_mobile
from common.util.loop_excel import excel_loop_data
from common.util.custom_code_component_location import custom_code_start, custom_code_end, custom_code_exit
from common.util.loop_code_component_location import *
from common.util.component_public_method import str_encryption
from common.util.pdb_util import process_debug
from common.util.shared_variables import GetSharedVariable
from projects.rpaRoot import SZEnv

import packages.WebBrowser.py.exports as WebBrowser
import packages.Bivartable.py.exports as Bivartable
from ..global_data import globalVar
from ..global_data import TASK_VARIABLE_MAP
from ..global_data import MOBILE_DEVICE_MAP
from ..global_data import GLOBAL_CONFIG_PASSWORD
from ..global_data import SHIZAI_ELEMENT_DICT
from ..global_data import run_module
self = SZEnv['rpa']
    
def main(rpa, **kw):
    global Log
    网页对象 = WebBrowser.GetTAB_V1(SZEnv['rpa'], "chrome", 2, "", "", 0, var_ret=0, skip_err=0, delay_before=200, delay_after=500, timeout=30000)  #@!io5cd@!-@!eJfTA@!-@!流程块1@!-@!获取网页 Tab 对象@!-@!1@!
    [批量采集结果, 采集页码] = WebBrowser.DataCrawl_web(SZEnv['rpa'], {"turnPageButtonInfo":{"nextBtnSelectorVersion":"1.1","nextBtnSelector":[{"name":"div","type":"web","accurate":"true","props":[{"name":"id","value":"\"pager\"","pattern":"equal","accurate":"true","textValue":"pager","expressionValue":"\"pager\""},{"name":"class","value":"\"fr\"","pattern":"equal","accurate":"false","textValue":"fr","expressionValue":"\"fr\""},{"name":"@index","value":"\"2\"","pattern":"equal","accurate":"false","textValue":"2","expressionValue":"\"2\""}]},{"name":"div","type":"web","accurate":"true","props":[{"name":"class","value":"\"pages\"","pattern":"equal","accurate":"false","textValue":"pages","expressionValue":"\"pages\""},{"name":"@index","value":"\"1\"","pattern":"equal","accurate":"false","textValue":"1","expressionValue":"\"1\""}]},{"name":"a","type":"web","accurate":"true","props":[{"name":"innertext","value":"\"下一页\"","pattern":"equal","accurate":"true","textValue":"下一页","expressionValue":"\"下一页\""},{"name":"@index","value":"\"5\"","pattern":"equal","accurate":"false","textValue":"5","expressionValue":"\"5\""}]}],"filePath":"res\\6c78bdac-dc24-45eb-80f0-de6d2713651c.png","delay":1000,"scrollVertical":0,"pageCount":99,"turnPageConfigType":2,"scrollDelay":200},"pageInfo":{"url":"https://xyq.cbg.163.com/cgi-bin/query.py?act=search_role&server_id=138&areaid=5&server_name=%C7%AE%CC%C1%BD%AD&page=1","title":"梦幻西游藏宝阁","guiType":"Chrome"},"collectInfo":{"type":"table","data":[{"CommonTalbleTitleList":[{"HasSet":0,"ColName":"A"},{"HasSet":0,"ColName":"B"},{"HasSet":0,"ColName":"C"},{"HasSet":0,"ColName":"D"},{"HasSet":0,"ColName":"E"},{"HasSet":0,"ColName":"F"},{"HasSet":0,"ColName":"G"},{"HasSet":0,"ColName":"H"}],"RegularConfigs":[],"version":"1.1","selector":[{"name":"table","type":"web","accurate":"true","props":[{"name":"id","value":"\"soldList\"","pattern":"equal","accurate":"true","textValue":"soldList","expressionValue":"\"soldList\""},{"name":"class","value":"\"tb01\"","pattern":"equal","accurate":"false","textValue":"tb01","expressionValue":"\"tb01\""}]}],"filePath":"res\\2576cbcc-2bcd-4141-af41-a3e7219448c5.png","title":"","dataType":1,"ExtendedInfo":{"talbleFeildTypeList":[0,0,0,0,0,0,0,1]},"regular":"","lastCaptureSelector":[]}]}}, None, 网页对象, 2, 53, 1, 0, "实在RPA-设计器数据采集结果_0SpYz.xls", "res", 10000, 50, 2000, 0, 1, 0, {"name": "data_collecting", "list": [{"name": "A", "type": "String", "comment": ""},{"name": "B", "type": "String", "comment": ""},{"name": "C", "type": "String", "comment": ""},{"name": "D", "type": "String", "comment": ""},{"name": "E", "type": "String", "comment": ""},{"name": "F", "type": "String", "comment": ""},{"name": "G", "type": "String", "comment": ""},{"name": "H", "type": "Int", "comment": ""}]}, var_ret=0, skip_err=0, delay_before=200, delay_after=50)  #@!io5cd@!-@!DZlD8@!-@!流程块1@!-@!数据采集@!-@!2@!
    数据表格_1 = Bivartable.CreateDfV1(SZEnv['rpa'], 1, 批量采集结果, "", "", "Sheet1", [], None, None, "", "object", {}, 0, {}, var_ret=0)  #@!io5cd@!-@!b9qYg@!-@!流程块1@!-@!创建数据表格@!-@!3@!
    custom_code_start(SZEnv['rpa'], "io5cd", "wfWPy", "TASK_COMPONENT_x0BtUyj1644395383923", "【二维表】创建对象", task_name="流程块1", component_sequence="4") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        df = run_module({ "module_path": "old_custom_components.x0BtUyj1644395383923_1_0_5" }, "main", SZEnv['rpa'], d_data=数据表格_1, d_index=[], d_columns=批量采集结果[0]) #@!io5cd@!-@!wfWPy@!-@!流程块1@!-@!【二维表】创建对象@!-@!4@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "io5cd", "wfWPy", "TASK_COMPONENT_x0BtUyj1644395383923", "【二维表】创建对象", task_name="流程块1", component_sequence="4") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "io5cd", "dFxra", "TASK_COMPONENT_Rr4Pw1w1644651854194", "【二维表】写入文件", task_name="流程块1", component_sequence="5") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        run_module({ "module_path": "old_custom_components.Rr4Pw1w1644651854194_1_0_9" }, "main", SZEnv['rpa'], d_df_input=df, d_file_path="C:\\Users\\chenliqi\\Desktop\\财经梦幻.xlsx", d_sheet_name="", d_has_index="否", d_has_header="是") #@!io5cd@!-@!dFxra@!-@!流程块1@!-@!【二维表】写入文件@!-@!5@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "io5cd", "dFxra", "TASK_COMPONENT_Rr4Pw1w1644651854194", "【二维表】写入文件", task_name="流程块1", component_sequence="5") #**EXTRA_CODE_SHIZAI**