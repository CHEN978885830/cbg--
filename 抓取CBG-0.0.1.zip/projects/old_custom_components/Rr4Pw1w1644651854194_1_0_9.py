
import sys
import os
from common.util.recursive_util import tail_call_optimized
from common.util.decryption_util import decrypt,encryption
from common.util.get_config_util import get_config
from common.util.log_util import trace_log
from common.util.option_util import options
from common.util.elements_util import elementsFormat, elementsFormatNew, collectElementsFormat, child_ele_eval
from common.util.judge_components import *
from common.util.selector_array import get_selector_array,get_selector_array_mobile
from common.util.loop_excel import excel_loop_data
from common.util.custom_code_component_location import custom_code_start, custom_code_end, custom_code_exit
from common.util.loop_code_component_location import *
from common.util.component_public_method import str_encryption
from common.util.pdb_util import process_debug
from common.util.shared_variables import GetSharedVariable
from projects.rpaRoot import SZEnv


import packages.App.py.exports as App
import packages.Array.py.exports as Array
import packages.Basic.py.exports as Basic
import packages.Bivartable.py.exports as Bivartable
import packages.Clipboard.py.exports as Clipboard
import packages.Collection.py.exports as Collection
import packages.CSV.py.exports as CSV
import packages.CustomConfig.py.exports as CustomConfig
import packages.CV.py.exports as CV
import packages.Database.py.exports as Database
import packages.DataService.py.exports as DataService
import packages.Dialog.py.exports as Dialog
import packages.Dict.py.exports as Dict
import packages.Element.py.exports as Element
import packages.Excel.py.exports as Excel
import packages.ExceptionUtil.py.exports as ExceptionUtil
import packages.File.py.exports as File
import packages.FileTypeConversion.py.exports as FileTypeConversion
import packages.FTP.py.exports as FTP
import packages.Http.py.exports as Http
import packages.Image.py.exports as Image
import packages.Ini.py.exports as Ini
import packages.JSON.py.exports as JSON
import packages.Keyboard.py.exports as Keyboard
import packages.List.py.exports as List
import packages.Log.py.exports as Log
import packages.Mail.py.exports as Mail
import packages.Mark.py.exports as Mark
import packages.Math.py.exports as Math
import packages.MessageNotification.py.exports as MessageNotification
import packages.Mobile.py.exports as Mobile
import packages.Mouse.py.exports as Mouse
import packages.NLP.py.exports as NLP
import packages.NLP_XunFei.py.exports as NLP_XunFei
import packages.OCR.py.exports as OCR
import packages.OcrOffline.py.exports as OcrOffline
import packages.OCR_BaiDu.py.exports as OCR_BaiDu
import packages.PDF.py.exports as PDF
import packages.peripherals.py.exports as peripherals
import packages.Regex.py.exports as Regex
import packages.SafeControlInput.py.exports as SafeControlInput
import packages.ScreenControl.py.exports as ScreenControl
import packages.StrUtil.py.exports as StrUtil
import packages.System.py.exports as System
import packages.Time.py.exports as Time
import packages.WebBrowser.py.exports as WebBrowser
import packages.Window.py.exports as Window
import packages.Word.py.exports as Word
from ..global_data import globalVar
from ..global_data import SHIZAI_ELEMENT_DICT
from ..global_data import TASK_VARIABLE_MAP
from ..global_data import MOBILE_DEVICE_MAP
from ..global_data import GLOBAL_CONFIG_PASSWORD
from ..global_data import run_module
self = SZEnv['rpa']
    
#【二维表】写入文件
@trace_log('【二维表】写入文件')
@options([])
def main(rpa, d_df_input = "",d_file_path = "",d_sheet_name = "",d_has_index = "否",d_has_header = "是",**kw):
    temp = None
    SHIZAI_ELEMENT_DICT = {}
    #@_折叠 导入相关第三方库 #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!E2nV5@!-@!【二维表】写入文件@!-@!未知组件@!-@!1@!
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "a3xrd", "base_command_custom", "插入代码", task_name="【二维表】写入文件", component_sequence="2") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        #@_插入代码 import os #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!a3xrd@!-@!【二维表】写入文件@!-@!插入代码@!-@!2@!
        import os  #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!a3xrd@!-@!【二维表】写入文件@!-@!插入代码@!-@!2@! #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!a3xrd@!-@!【二维表】写入文件@!-@!插入代码@!-@!2@!
        #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!a3xrd@!-@!【二维表】写入文件@!-@!插入代码@!-@!2@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "a3xrd", "base_command_custom", "插入代码", task_name="【二维表】写入文件", component_sequence="2") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "hL3Ls", "base_command_custom", "插入代码", task_name="【二维表】写入文件", component_sequence="3") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        #@_插入代码 import openpyxl #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!hL3Ls@!-@!【二维表】写入文件@!-@!插入代码@!-@!3@!
        import openpyxl  #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!hL3Ls@!-@!【二维表】写入文件@!-@!插入代码@!-@!3@! #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!hL3Ls@!-@!【二维表】写入文件@!-@!插入代码@!-@!3@!
        #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!hL3Ls@!-@!【二维表】写入文件@!-@!插入代码@!-@!3@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "hL3Ls", "base_command_custom", "插入代码", task_name="【二维表】写入文件", component_sequence="3") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "US7nZ", "base_command_custom", "插入代码", task_name="【二维表】写入文件", component_sequence="4") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        #@_插入代码 import pandas as pd #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!US7nZ@!-@!【二维表】写入文件@!-@!插入代码@!-@!4@!
        import pandas as pd  #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!US7nZ@!-@!【二维表】写入文件@!-@!插入代码@!-@!4@! #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!US7nZ@!-@!【二维表】写入文件@!-@!插入代码@!-@!4@!
        #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!US7nZ@!-@!【二维表】写入文件@!-@!插入代码@!-@!4@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "US7nZ", "base_command_custom", "插入代码", task_name="【二维表】写入文件", component_sequence="4") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "xIfrl", "base_command_custom", "插入代码", task_name="【二维表】写入文件", component_sequence="5") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        #@_插入代码 获取变量名 #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!xIfrl@!-@!【二维表】写入文件@!-@!插入代码@!-@!5@!
        import inspect  #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!xIfrl@!-@!【二维表】写入文件@!-@!插入代码@!-@!5@!
        
        def get_varname(var):
            for fi in reversed(inspect.stack()):
                names = [var_name for var_name, var_val in fi.frame.f_locals.items() if var_val is var]
                if len(names) > 0:
                    return names[0] #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!xIfrl@!-@!【二维表】写入文件@!-@!插入代码@!-@!5@!
        #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!xIfrl@!-@!【二维表】写入文件@!-@!插入代码@!-@!5@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "xIfrl", "base_command_custom", "插入代码", task_name="【二维表】写入文件", component_sequence="5") #**EXTRA_CODE_SHIZAI**
    #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!E2nV5@!-@!【二维表】写入文件@!-@!未知组件@!-@!1@!
    # #@_折叠 【测试】请求参数 #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!rL2Aa@!-@!【二维表】写入文件@!-@!未知组件@!-@!6@!
    # custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "Ek009", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="7") #**EXTRA_CODE_SHIZAI**
    # try: #**EXTRA_CODE_SHIZAI**
    #     d_df_input = pd.DataFrame([["叶斌","十一班"],["艾尔","一班"],["爱德华","二班"]],columns=["姓名","班级"]) #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!Ek009@!-@!【二维表】写入文件@!-@!设置变量@!-@!7@!
    # finally: #**EXTRA_CODE_SHIZAI**
    #     custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "Ek009", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="7") #**EXTRA_CODE_SHIZAI**
    # custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "ShBS7", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="8") #**EXTRA_CODE_SHIZAI**
    # try: #**EXTRA_CODE_SHIZAI**
    #     d_file_path = r"C:\Users\Lenovo\Desktop\写入文件-测试.csv" #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!ShBS7@!-@!【二维表】写入文件@!-@!设置变量@!-@!8@!
    # finally: #**EXTRA_CODE_SHIZAI**
    #     custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "ShBS7", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="8") #**EXTRA_CODE_SHIZAI**
    # custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "kgZPF", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="9") #**EXTRA_CODE_SHIZAI**
    # try: #**EXTRA_CODE_SHIZAI**
    #     d_file_path = r"C:\Users\Lenovo\Desktop\写入文件-测试.xlsx" #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!kgZPF@!-@!【二维表】写入文件@!-@!设置变量@!-@!9@!
    # finally: #**EXTRA_CODE_SHIZAI**
    #     custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "kgZPF", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="9") #**EXTRA_CODE_SHIZAI**
    # custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "M7Gil", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="10") #**EXTRA_CODE_SHIZAI**
    # try: #**EXTRA_CODE_SHIZAI**
    #     d_sheet_name = "信息表" #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!M7Gil@!-@!【二维表】写入文件@!-@!设置变量@!-@!10@!
    # finally: #**EXTRA_CODE_SHIZAI**
    #     custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "M7Gil", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="10") #**EXTRA_CODE_SHIZAI**
    # custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "cNqiO", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="11") #**EXTRA_CODE_SHIZAI**
    # try: #**EXTRA_CODE_SHIZAI**
    #     d_has_index = "是" #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!cNqiO@!-@!【二维表】写入文件@!-@!设置变量@!-@!11@!
    # finally: #**EXTRA_CODE_SHIZAI**
    #     custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "cNqiO", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="11") #**EXTRA_CODE_SHIZAI**
    # custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "Zwn9u", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="12") #**EXTRA_CODE_SHIZAI**
    # try: #**EXTRA_CODE_SHIZAI**
    #     d_has_index = "否" #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!Zwn9u@!-@!【二维表】写入文件@!-@!设置变量@!-@!12@!
    # finally: #**EXTRA_CODE_SHIZAI**
    #     custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "Zwn9u", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="12") #**EXTRA_CODE_SHIZAI**
    # custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "GkJ4H", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="13") #**EXTRA_CODE_SHIZAI**
    # try: #**EXTRA_CODE_SHIZAI**
    #     d_has_header = "否" #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!GkJ4H@!-@!【二维表】写入文件@!-@!设置变量@!-@!13@!
    # finally: #**EXTRA_CODE_SHIZAI**
    #     custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "GkJ4H", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="13") #**EXTRA_CODE_SHIZAI**
    # Log.Info(SZEnv['rpa'], d_df_input)  #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!kYBci@!-@!【二维表】写入文件@!-@!打印普通日志@!-@!14@!
    # #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!rL2Aa@!-@!【二维表】写入文件@!-@!未知组件@!-@!6@!
    #@_折叠 初始化参数 or 参数校验 #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!CCziS@!-@!【二维表】写入文件@!-@!未知组件@!-@!15@!
    pass
    #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!CCziS@!-@!【二维表】写入文件@!-@!未知组件@!-@!15@!
    #@_折叠 具体逻辑处理 #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!c3llw@!-@!【二维表】写入文件@!-@!未知组件@!-@!16@!
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "FoDHX", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="17") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        suffix = os.path.splitext(d_file_path)[-1] #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!FoDHX@!-@!【二维表】写入文件@!-@!设置变量@!-@!17@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "FoDHX", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="17") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "FinPg", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="18") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        d_has_index = True if d_has_index == "是" else False #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!FinPg@!-@!【二维表】写入文件@!-@!设置变量@!-@!18@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "FinPg", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="18") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "6qwTk", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="19") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        d_has_header = True if d_has_header == "是" else False #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!6qwTk@!-@!【二维表】写入文件@!-@!设置变量@!-@!19@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "6qwTk", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="19") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "sgASZ", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="20") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        d_sheet_name = "Sheet1" if d_sheet_name == "" else d_sheet_name #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!sgASZ@!-@!【二维表】写入文件@!-@!设置变量@!-@!20@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "sgASZ", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="20") #**EXTRA_CODE_SHIZAI**
    if (suffix in [".csv"]): #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!cyELL@!-@!【二维表】写入文件@!-@!添加条件判断(if)@!-@!21@!
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "qUFox", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="22") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            temp = d_df_input.to_csv(d_file_path,index=d_has_index,header=d_has_header,encoding="gb18030") #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!qUFox@!-@!【二维表】写入文件@!-@!设置变量@!-@!22@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "qUFox", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="22") #**EXTRA_CODE_SHIZAI**
    elif (suffix in [".xlsx",".xls"]): #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!CkYHG@!-@!【二维表】写入文件@!-@!否则如果(else-if)@!-@!23@!
        #@_折叠 仅单个sheet #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!keIsD@!-@!【二维表】写入文件@!-@!未知组件@!-@!24@!
        if (not os.path.exists(d_file_path)): #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!amOUG@!-@!【二维表】写入文件@!-@!添加条件判断(if)@!-@!25@!
            custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "miDle", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="26") #**EXTRA_CODE_SHIZAI**
            try: #**EXTRA_CODE_SHIZAI**
                temp = d_df_input.to_excel(d_file_path,sheet_name=d_sheet_name,index=d_has_index,header=d_has_header) #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!miDle@!-@!【二维表】写入文件@!-@!设置变量@!-@!26@!
            finally: #**EXTRA_CODE_SHIZAI**
                custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "miDle", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="26") #**EXTRA_CODE_SHIZAI**
            custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "ZcbuK", "logic_control_stop_return", "跳出流程", task_name="【二维表】写入文件", component_sequence="27") #**EXTRA_CODE_SHIZAI**
            try: #**EXTRA_CODE_SHIZAI**
                return None #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!ZcbuK@!-@!【二维表】写入文件@!-@!跳出流程@!-@!27@!
            finally: #**EXTRA_CODE_SHIZAI**
                custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "ZcbuK", "logic_control_stop_return", "跳出流程", task_name="【二维表】写入文件", component_sequence="27") #**EXTRA_CODE_SHIZAI**
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "DRgcj", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="28") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            sheet_list = list(pd.read_excel(d_file_path,sheet_name=None).keys()) #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!DRgcj@!-@!【二维表】写入文件@!-@!设置变量@!-@!28@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "DRgcj", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="28") #**EXTRA_CODE_SHIZAI**
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "Mrkqd", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="29") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            is_new = False if d_sheet_name in sheet_list else True #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!Mrkqd@!-@!【二维表】写入文件@!-@!设置变量@!-@!29@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "Mrkqd", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="29") #**EXTRA_CODE_SHIZAI**
        if (len(sheet_list) < 2) and (not is_new): #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!CRivc@!-@!【二维表】写入文件@!-@!添加条件判断(if)@!-@!30@!
            custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "5Df5T", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="31") #**EXTRA_CODE_SHIZAI**
            try: #**EXTRA_CODE_SHIZAI**
                temp = d_df_input.to_excel(d_file_path,sheet_name=d_sheet_name,index=d_has_index,header=d_has_header) #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!5Df5T@!-@!【二维表】写入文件@!-@!设置变量@!-@!31@!
            finally: #**EXTRA_CODE_SHIZAI**
                custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "5Df5T", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="31") #**EXTRA_CODE_SHIZAI**
            custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "wbibt", "logic_control_stop_return", "跳出流程", task_name="【二维表】写入文件", component_sequence="32") #**EXTRA_CODE_SHIZAI**
            try: #**EXTRA_CODE_SHIZAI**
                return None #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!wbibt@!-@!【二维表】写入文件@!-@!跳出流程@!-@!32@!
            finally: #**EXTRA_CODE_SHIZAI**
                custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "wbibt", "logic_control_stop_return", "跳出流程", task_name="【二维表】写入文件", component_sequence="32") #**EXTRA_CODE_SHIZAI**
        #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!keIsD@!-@!【二维表】写入文件@!-@!未知组件@!-@!24@!
        #@_折叠 多个sheet #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!B5DzD@!-@!【二维表】写入文件@!-@!未知组件@!-@!33@!
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "cap4F", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="34") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            book = openpyxl.load_workbook(d_file_path) #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!cap4F@!-@!【二维表】写入文件@!-@!设置变量@!-@!34@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "cap4F", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="34") #**EXTRA_CODE_SHIZAI**
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "AeByf", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="35") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            writer = pd.ExcelWriter(d_file_path,engine="openpyxl") #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!AeByf@!-@!【二维表】写入文件@!-@!设置变量@!-@!35@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "AeByf", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="35") #**EXTRA_CODE_SHIZAI**
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "vA2wA", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="36") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            writer.book = book #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!vA2wA@!-@!【二维表】写入文件@!-@!设置变量@!-@!36@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "vA2wA", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="36") #**EXTRA_CODE_SHIZAI**
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "BQi5B", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="37") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            wb = writer.book #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!BQi5B@!-@!【二维表】写入文件@!-@!设置变量@!-@!37@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "BQi5B", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="37") #**EXTRA_CODE_SHIZAI**
        if (not is_new): #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!NbA3t@!-@!【二维表】写入文件@!-@!添加条件判断(if)@!-@!38@!
            custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "sosPT", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="39") #**EXTRA_CODE_SHIZAI**
            try: #**EXTRA_CODE_SHIZAI**
                temp = wb.remove(wb[d_sheet_name]) #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!sosPT@!-@!【二维表】写入文件@!-@!设置变量@!-@!39@!
            finally: #**EXTRA_CODE_SHIZAI**
                custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "sosPT", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="39") #**EXTRA_CODE_SHIZAI**
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "dcxL5", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="40") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            temp = d_df_input.to_excel(writer,sheet_name=d_sheet_name,index=d_has_index,header=d_has_header) #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!dcxL5@!-@!【二维表】写入文件@!-@!设置变量@!-@!40@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "dcxL5", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="40") #**EXTRA_CODE_SHIZAI**
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "fWChb", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="41") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            temp = writer.save() #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!fWChb@!-@!【二维表】写入文件@!-@!设置变量@!-@!41@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "fWChb", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="41") #**EXTRA_CODE_SHIZAI**
        custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "4kxC4", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="42") #**EXTRA_CODE_SHIZAI**
        try: #**EXTRA_CODE_SHIZAI**
            temp = writer.close() #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!4kxC4@!-@!【二维表】写入文件@!-@!设置变量@!-@!42@!
        finally: #**EXTRA_CODE_SHIZAI**
            custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_Rr4Pw1w1644651854194", "4kxC4", "logic_control_var", "设置变量", task_name="【二维表】写入文件", component_sequence="42") #**EXTRA_CODE_SHIZAI**
        #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!B5DzD@!-@!【二维表】写入文件@!-@!未知组件@!-@!33@!
    #@ #@!TASK_COMPONENT_Rr4Pw1w1644651854194@!-@!c3llw@!-@!【二维表】写入文件@!-@!未知组件@!-@!16@!
    return temp