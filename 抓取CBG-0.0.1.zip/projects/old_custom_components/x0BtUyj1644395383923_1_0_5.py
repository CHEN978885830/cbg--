
import sys
import os
from common.util.recursive_util import tail_call_optimized
from common.util.decryption_util import decrypt,encryption
from common.util.get_config_util import get_config
from common.util.log_util import trace_log
from common.util.option_util import options
from common.util.elements_util import elementsFormat, elementsFormatNew, collectElementsFormat, child_ele_eval
from common.util.judge_components import *
from common.util.selector_array import get_selector_array,get_selector_array_mobile
from common.util.loop_excel import excel_loop_data
from common.util.custom_code_component_location import custom_code_start, custom_code_end, custom_code_exit
from common.util.loop_code_component_location import *
from common.util.component_public_method import str_encryption
from common.util.pdb_util import process_debug
from common.util.shared_variables import GetSharedVariable
from projects.rpaRoot import SZEnv


import packages.App.py.exports as App
import packages.Array.py.exports as Array
import packages.Basic.py.exports as Basic
import packages.Bivartable.py.exports as Bivartable
import packages.Clipboard.py.exports as Clipboard
import packages.Collection.py.exports as Collection
import packages.CSV.py.exports as CSV
import packages.CustomConfig.py.exports as CustomConfig
import packages.CV.py.exports as CV
import packages.Database.py.exports as Database
import packages.DataService.py.exports as DataService
import packages.Dialog.py.exports as Dialog
import packages.Dict.py.exports as Dict
import packages.Element.py.exports as Element
import packages.Excel.py.exports as Excel
import packages.ExceptionUtil.py.exports as ExceptionUtil
import packages.File.py.exports as File
import packages.FileTypeConversion.py.exports as FileTypeConversion
import packages.FTP.py.exports as FTP
import packages.Http.py.exports as Http
import packages.Image.py.exports as Image
import packages.Ini.py.exports as Ini
import packages.JSON.py.exports as JSON
import packages.Keyboard.py.exports as Keyboard
import packages.List.py.exports as List
import packages.Log.py.exports as Log
import packages.Mail.py.exports as Mail
import packages.Mark.py.exports as Mark
import packages.Math.py.exports as Math
import packages.MessageNotification.py.exports as MessageNotification
import packages.Mobile.py.exports as Mobile
import packages.Mouse.py.exports as Mouse
import packages.NLP.py.exports as NLP
import packages.NLP_XunFei.py.exports as NLP_XunFei
import packages.OCR.py.exports as OCR
import packages.OcrOffline.py.exports as OcrOffline
import packages.OCR_BaiDu.py.exports as OCR_BaiDu
import packages.PDF.py.exports as PDF
import packages.peripherals.py.exports as peripherals
import packages.Regex.py.exports as Regex
import packages.SafeControlInput.py.exports as SafeControlInput
import packages.ScreenControl.py.exports as ScreenControl
import packages.StrUtil.py.exports as StrUtil
import packages.System.py.exports as System
import packages.Time.py.exports as Time
import packages.WebBrowser.py.exports as WebBrowser
import packages.Window.py.exports as Window
import packages.Word.py.exports as Word
from ..global_data import globalVar
from ..global_data import SHIZAI_ELEMENT_DICT
from ..global_data import TASK_VARIABLE_MAP
from ..global_data import MOBILE_DEVICE_MAP
from ..global_data import GLOBAL_CONFIG_PASSWORD
from ..global_data import run_module
self = SZEnv['rpa']
    
#【二维表】创建对象
@trace_log('【二维表】创建对象')
@options([])
def main(rpa, d_data = [],d_index = [],d_columns = [],**kw):
    d_df = None
    SHIZAI_ELEMENT_DICT = {}
    #@_折叠 导入相关第三方库 #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!YPYus@!-@!【二维表】创建对象@!-@!未知组件@!-@!1@!
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "I38w4", "base_command_custom", "插入代码", task_name="【二维表】创建对象", component_sequence="2") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        #@_插入代码 import pandas as pd #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!I38w4@!-@!【二维表】创建对象@!-@!插入代码@!-@!2@!
        import pandas as pd  #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!I38w4@!-@!【二维表】创建对象@!-@!插入代码@!-@!2@! #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!I38w4@!-@!【二维表】创建对象@!-@!插入代码@!-@!2@!
        #@ #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!I38w4@!-@!【二维表】创建对象@!-@!插入代码@!-@!2@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "I38w4", "base_command_custom", "插入代码", task_name="【二维表】创建对象", component_sequence="2") #**EXTRA_CODE_SHIZAI**
    #@ #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!YPYus@!-@!【二维表】创建对象@!-@!未知组件@!-@!1@!
    #@_折叠 【测试】请求参数 #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!fRW7Q@!-@!【二维表】创建对象@!-@!未知组件@!-@!3@!
    pass
    #@ #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!fRW7Q@!-@!【二维表】创建对象@!-@!未知组件@!-@!3@!
    #@_折叠 初始化参数 or 参数校验 #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!8bsCB@!-@!【二维表】创建对象@!-@!未知组件@!-@!4@!
    pass
    #@ #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!8bsCB@!-@!【二维表】创建对象@!-@!未知组件@!-@!4@!
    #@_折叠 具体逻辑处理 #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!Yrfzb@!-@!【二维表】创建对象@!-@!未知组件@!-@!5@!
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "tf3mZ", "logic_control_var", "设置变量", task_name="【二维表】创建对象", component_sequence="6") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        d_index = None if len(d_index) == 0  else d_index #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!tf3mZ@!-@!【二维表】创建对象@!-@!设置变量@!-@!6@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "tf3mZ", "logic_control_var", "设置变量", task_name="【二维表】创建对象", component_sequence="6") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "wC6PC", "logic_control_var", "设置变量", task_name="【二维表】创建对象", component_sequence="7") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        d_columns = None if len(d_columns) == 0  else d_columns #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!wC6PC@!-@!【二维表】创建对象@!-@!设置变量@!-@!7@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "wC6PC", "logic_control_var", "设置变量", task_name="【二维表】创建对象", component_sequence="7") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "kWwLd", "logic_control_var", "设置变量", task_name="【二维表】创建对象", component_sequence="8") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        d_df = pd.DataFrame(d_data,index=d_index,columns=d_columns) #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!kWwLd@!-@!【二维表】创建对象@!-@!设置变量@!-@!8@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "kWwLd", "logic_control_var", "设置变量", task_name="【二维表】创建对象", component_sequence="8") #**EXTRA_CODE_SHIZAI**
    custom_code_start(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "jln8m", "logic_control_stop_return", "跳出流程", task_name="【二维表】创建对象", component_sequence="9") #**EXTRA_CODE_SHIZAI**
    try: #**EXTRA_CODE_SHIZAI**
        return d_df #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!jln8m@!-@!【二维表】创建对象@!-@!跳出流程@!-@!9@!
    finally: #**EXTRA_CODE_SHIZAI**
        custom_code_end(SZEnv['rpa'], "TASK_COMPONENT_x0BtUyj1644395383923", "jln8m", "logic_control_stop_return", "跳出流程", task_name="【二维表】创建对象", component_sequence="9") #**EXTRA_CODE_SHIZAI**
    #@ #@!TASK_COMPONENT_x0BtUyj1644395383923@!-@!Yrfzb@!-@!【二维表】创建对象@!-@!未知组件@!-@!5@!
    return d_df